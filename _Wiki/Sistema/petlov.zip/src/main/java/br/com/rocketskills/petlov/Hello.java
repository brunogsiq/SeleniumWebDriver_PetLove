package br.com.rocketskills.petlov;

class Hello {
	static public void main(String args[]) {
		System.out.println("Olá QA!");
	}
}